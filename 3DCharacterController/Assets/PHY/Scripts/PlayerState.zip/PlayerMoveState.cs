
using UnityEngine;

public class PlayerMoveState : PlayerBaseState
{
    private readonly ParkourDetector parkourDetector;
    private readonly ParkourConditionChecker parkourChecker;

    public PlayerMoveState(
        PlayerController _playerController,
        PlayerStateMachine _playerStateMachine)
        : base(_playerController, _playerStateMachine)
    {
        parkourDetector =
            playerController.GetComponent<ParkourDetector>();

        parkourChecker =
            playerController.GetComponent<ParkourConditionChecker>();
    }

    public override void Enter()
    {
        playerController.PlayerAnimationController.SetAirborne(false);
        playerController.PlayerAnimationController.SetLanding(false);
        playerController.PlayerAnimationController.SetMoveInput(true);
        playerController.PlayerAnimationController.SetMotion(PlayerMotion.Locomotion);

        Debug.Log("move enter");
    }

    public override void Update()
    {
        if (playerController.ShouldStartFalling)
        {
            playerStateMachine.ChangeState(
                new PlayerFallState(
                    playerController,
                    playerStateMachine,
                    false));
            return;
        }

        bool canJump =
            playerController.InputHandler.JumpPressed &&
            playerController.GroundDetector.IsGrounded &&
            playerController.GroundDetector.IsWalkableSlope;

        if (canJump)
        {
            if (parkourDetector != null &&
                parkourDetector.HasObstacle &&
                parkourChecker != null)
            {
                bool canParkour =
                    parkourChecker.CanExecute(
                        out string reason);

                if (canParkour)
                {
                    Debug.Log(
                        $"[Parkour] Move -> " +
                        $"{parkourDetector.CurrentObstacle.Type} " +
                        $"���� ���� ���");

                    // �߰�: Vault Ÿ�Ը� VaultState�� ��ȯ
                    if (parkourDetector.CurrentObstacle.Type ==
                        ParkourType.Vault)
                    {
                        playerController.InputHandler.ResetJumpInput();

                        playerStateMachine.ChangeState(
                            new PlayerVaultState(
                                playerController,
                                playerStateMachine));

                        return;
                    }
                }
                else
                {
                    Debug.Log(
                        $"[Parkour] Move ���� �Ұ�: {reason}");
                }
            }

            Debug.Log("move -> jump ����");

            playerController.InputHandler.ResetJumpInput();

            playerStateMachine.ChangeState(
                new PlayerJumpState(
                    playerController,
                    playerStateMachine,
                    false));
            return;
        }

        if (playerController.InputHandler.Movement.sqrMagnitude <= 0.01f)
        {
            playerStateMachine.ChangeState(
                new PlayerIdleState(
                    playerController,
                    playerStateMachine));
            return;
        }
    }

    public override void Exit()
    {
        Debug.Log("move exit");
    }
}
