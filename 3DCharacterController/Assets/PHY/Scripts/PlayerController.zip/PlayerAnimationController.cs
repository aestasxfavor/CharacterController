
using UnityEngine;

public class PlayerAnimationController : MonoBehaviour
{
    [SerializeField] private Animator animator;
    [SerializeField] private CharacterController characterController;
    [SerializeField] private GroundDetector groundDetector;
    [SerializeField] private JumpController jumpController;
    [SerializeField] private MovementController movementController;
    [SerializeField] private PlayerController playerController;     // �߰�: Root Motion ���� ���

    private readonly int SpeedHash = Animator.StringToHash("Speed");
    private readonly int YSpeedHash = Animator.StringToHash("YSpeed");
    private readonly int IsAirborneHash = Animator.StringToHash("IsAirborne");
    private readonly int IsGroundedHash = Animator.StringToHash("IsGrounded");
    private readonly int IsLandingHash = Animator.StringToHash("IsLanding");
    private readonly int HasMoveInputHash = Animator.StringToHash("HasMoveInput");
    private readonly int MotionStateHash = Animator.StringToHash("MotionState");
    private readonly string IdleJumpTrigger = "IdleJumpTrigger";

    // ���� ������ Animation Event�� �����ִ� ���� ���� �÷���
    public bool ParkourExitWindowOpened { get; private set; }

    // ������ �������� ��Ʈ��� �ӵ� (������ ���� �� MovementController�� �ΰ�)
    public Vector3 RootMotionVelocity { get; private set; }

    private void Reset()
    {
        characterController = GetComponent<CharacterController>();
        groundDetector = GetComponent<GroundDetector>();
        jumpController = GetComponent<JumpController>();
        movementController = GetComponent<MovementController>();
        animator = GetComponent<Animator>();
        playerController = GetComponentInParent<PlayerController>();
    }

    private void Awake()
    {
        if (characterController == null)
            characterController = GetComponent<CharacterController>();

        if (groundDetector == null)
            groundDetector = GetComponent<GroundDetector>();

        if (jumpController == null)
            jumpController = GetComponent<JumpController>();

        if (movementController == null)
            movementController = GetComponent<MovementController>();

        if (animator == null)
            animator = GetComponent<Animator>();

        // �߰�
        if (playerController == null)
            playerController = GetComponentInParent<PlayerController>();
    }

    private void Update()
    {
        if (!IsAnimationReady()) return;

        UpdateMoveSpeed();

        SetYSpeed(jumpController.VerticalVelocity);
        SetGrounded(groundDetector.IsGrounded);
    }

    // �߰�: Vault �� Root Motion ����
    private void OnAnimatorMove()
    {
        if (animator == null) return;

        // �߰�: �̹� ������ ��Ʈ��� �ӵ� ���
        RootMotionVelocity = Time.deltaTime > 0f
            ? animator.deltaPosition / Time.deltaTime
            : Vector3.zero;


        if (playerController == null || !playerController.IsParkourActive)
        {
            // ���� Animator�� Root Motion ���� ����
            if (animator.applyRootMotion)
            {
                animator.ApplyBuiltinRootMotion();
            }
            return;
        }

        playerController.ApplyParkourRootMotion(animator.deltaPosition);
    }

    private void UpdateMoveSpeed()
    {
        if (movementController.RunSpeed <= 0f)
        {
            SetSpeed(0f);
            return;
        }

        float normalizedSpeed =
            movementController.CurrentHorizontalSpeed /
            movementController.RunSpeed;

        normalizedSpeed = Mathf.Clamp01(normalizedSpeed);

        SetSpeed(normalizedSpeed);
    }

    public void SetSpeed(float value)
    {
        if (animator == null) return;

        animator.SetFloat(
            SpeedHash,
            value,
            0.05f,
            Time.deltaTime);
    }

    public PlayerMotion CurrentMotion { get; private set; }

    public void SetMotion(PlayerMotion motion)
    {
        CurrentMotion = motion;

        if (animator == null) return;

        animator.SetInteger(
            MotionStateHash,
            (int)motion);
    }

    // ������ Animator State�� �ִϸ��̼� ��� �Ϸ� ���� Ȯ��
    // State ��ȯ ���̰ų� �ش� State�� �ƴϸ� false ��ȯ
    // �ݺ� ������� �ʴ� ���� ���� Ŭ������ ���
    public bool IsMotionComplete(string stateName)
    {
        if (animator == null)
        {
            return false;
        }

        if (animator.IsInTransition(0))
        {
            return false;
        }

        AnimatorStateInfo stateInfo =
            animator.GetCurrentAnimatorStateInfo(0);

        return stateInfo.IsName(stateName) &&
               stateInfo.normalizedTime >= 1f;
    }

    public void SetYSpeed(float value)
    {
        if (animator == null) return;

        animator.SetFloat(YSpeedHash, value);
    }

    public void SetGrounded(bool value)
    {
        if (animator == null) return;

        animator.SetBool(IsGroundedHash, value);
    }

    public void SetAirborne(bool value)
    {
        if (animator == null) return;

        animator.SetBool(IsAirborneHash, value);
    }

    public void SetLanding(bool value)
    {
        if (animator == null) return;

        animator.SetBool(IsLandingHash, value);
    }

    public void SetMoveInput(bool value)
    {
        if (animator == null) return;

        animator.SetBool(HasMoveInputHash, value);
    }

    public void TriggerIdleJump()
    {
        if (animator == null) return;

        animator.SetTrigger(IdleJumpTrigger);
    }

    private bool IsAnimationReady()
    {
        return animator != null
            && characterController != null
            && groundDetector != null
            && jumpController != null
            && movementController != null;
    }

    // Animation Event ���ſ�. Ŭ�� Events�� �� �̸����� ����Ѵ�.
    // Mantle, Slide ����� ���� �̸��� �����Ѵ�.
    public void OnParkourExitWindow()
    {
        ParkourExitWindowOpened = true;
        Debug.Log("[Anim] ParkourExitWindow");
    }

    public void ResetParkourExitWindow()
    {
        ParkourExitWindowOpened = false;
    }
}
