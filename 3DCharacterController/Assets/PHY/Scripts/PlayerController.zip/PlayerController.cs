using UnityEngine;

/// <summary>
/// 2026-04-21
/// ������ٵ� ��� ��Ʈ�ѷ����� ĳ���� ��Ʈ�ѷ� + ������ٵ� �Ϻθ� ����� ĳ���� ��Ʈ�ѷ� ���� ����
/// </summary>
public class PlayerController : MonoBehaviour
{
    [Header("Components")]
    [SerializeField] private CharacterController characterController;
    [SerializeField] private PlayerAnimationController playerAnimationController;
    private Transform cameraTransform;

    [Header("Controllers")]
    [SerializeField] private InputHandler inputHandler;
    [SerializeField] private MovementController movementController;
    [SerializeField] private JumpController jumpController;
    [SerializeField] private GroundDetector groundDetector;
    [SerializeField] private HighFallDetector highFallDetector;

    [Header("StatePatterns")]
    [SerializeField] private PlayerStateMachine playerStateMachine;

    [Header("Air State")]
    [SerializeField] private float fallThreshold = -0.5f;

    [Header("Debug")]
    [SerializeField] private bool showDebugLog = true;

    public CharacterController CharacterController => characterController;
    public PlayerAnimationController PlayerAnimationController => playerAnimationController;
    public InputHandler InputHandler => inputHandler;
    public MovementController MovementController => movementController;
    public JumpController JumpController => jumpController;
    public GroundDetector GroundDetector => groundDetector;
    public HighFallDetector HighFallDetector => highFallDetector;

    public float FallThreshold => fallThreshold;

    public float JumpStartY => jumpStartY;
    private float jumpStartY;

    public bool WasGrounded => wasGrounded;
    private bool wasGrounded;

    public bool ControllerGroundedAfterMove { get; private set; }

    private void Reset()
    {
        FindRefernces();
        //characterController = GetComponent<CharacterController>();
        //inputHandler = GetComponent<InputHandler>();
        //movementController = GetComponent<MovementController>();
        //jumpController = GetComponent<JumpController>();
        //groundDetector = GetComponent<GroundDetector>();
        //highFallDetector = GetComponent<HighFallDetector>();
        //playerAnimationController = GetComponent<PlayerAnimationController>();
        //playerStateMachine = GetComponent<PlayerStateMachine>();
    }

    private void Awake()
    {
        FindRefernces();
    }

    private void Start()
    {
        groundDetector.CheckGround();
        wasGrounded = groundDetector.IsGrounded;

        if (playerStateMachine != null)
        {
            playerStateMachine.ChangeState(new PlayerIdleState(this, playerStateMachine));
        }
    }

    public void SetCameraTransform(Transform newCameraTransform)
    {
        cameraTransform = newCameraTransform;
    }

    private void Update()
    {
        if (!IsReady()) return;

        ControllerGroundedAfterMove = false;

        wasGrounded = groundDetector.IsGrounded;

        groundDetector.CheckGround();

        // JumpController�� ���� �ӵ� ������ ���� ������ ��� �ʿ��ϹǷ�
        // Raycast ��� GroundDetector�� �ƴ� CharacterController�� ���� ������ ����Ѵ�.
        jumpController.UpdateVertical(characterController.isGrounded, Time.deltaTime);

        ProcessMovement();

        playerStateMachine.UpdateState();
    }

    private void ProcessMovement()
    {
        Vector3 moveDirection = movementController.GetMoveDirection(inputHandler.Movement, cameraTransform);

        bool hasMoveInput = moveDirection.sqrMagnitude > 0.01f;
        bool isRunPressed = inputHandler.IsRunPressed;

        playerAnimationController.SetMoveInput(hasMoveInput);

        Vector3 horizontalMove = movementController.GetHorizontalMove(moveDirection, Time.deltaTime, 
            groundDetector.IsGrounded, isRunPressed);

        Vector3 finalMove = horizontalMove;
        finalMove.y = jumpController.VerticalVelocity;

        // CollisionFlags: Move �� ĳ���� ��Ʈ�ѷ��� � �������� �浹�� �־����� �˷��ִ� �÷���
        CollisionFlags flags = characterController.Move(finalMove * Time.deltaTime);

        bool hitBelow = (flags & CollisionFlags.Below) != 0;

        groundDetector.CheckGround();

        // CharacterController.Move ���� ���� �Ʒ� ���� �浹�� �־����� Ȯ����
        // FallState�� ���� ���� �������� ����Ѵ�.
        ControllerGroundedAfterMove = hitBelow && groundDetector.IsGrounded;

        if (hasMoveInput && groundDetector.IsGrounded)
        {
            movementController.Rotate(transform, moveDirection, Time.deltaTime);
        }
    }

    public void SetJumpStartY(float value)
    {
        jumpStartY = value;
    }

    private bool IsReady()
    {
        return characterController != null
            && inputHandler != null
            && movementController != null
            && jumpController != null
            && groundDetector != null
            && highFallDetector != null
            && playerAnimationController != null
            && cameraTransform != null;
    }

    private void FindRefernces()
    {
        if (characterController == null) characterController = GetComponent<CharacterController>();
        if (inputHandler == null) inputHandler = GetComponent<InputHandler>();
        if (movementController == null) movementController = GetComponent<MovementController>();
        if (jumpController == null) jumpController = GetComponent<JumpController>();
        if (groundDetector == null) groundDetector = GetComponent<GroundDetector>();
        if (highFallDetector == null) highFallDetector = GetComponent<HighFallDetector>();
        if (playerAnimationController == null) playerAnimationController = GetComponent<PlayerAnimationController>();
        if (playerStateMachine == null) playerStateMachine = GetComponent<PlayerStateMachine>();
    }
}