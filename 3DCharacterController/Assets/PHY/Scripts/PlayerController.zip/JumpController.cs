
using UnityEngine;

/// <summary>
/// ������ �߷¿� ���� ���� �ӵ��� ����ϴ� ��Ʈ�ѷ�
/// ���� �̵��� MovementController���� ó��
/// </summary>
public class JumpController : MonoBehaviour
{
    [Header("Jump Settings")]
    [SerializeField] private float jumpPower = 6f;
    [SerializeField] private float gravityScale = 3.5f;
    [SerializeField] private float maxFallSpeed = 20f;
    [SerializeField] private float groundStickVelocity = -0.5f;

    [Header("Debug")]
    [SerializeField] private bool showJumpDebug = true;

    public float VerticalVelocity { get; private set; }
    public bool IsJumping { get; private set; }

    private bool hasLeftGround;

    // �α� ��� ���� �����
    private float nextDebugTime;

    public void TryJump(bool isGrounded)
    {
        if (!isGrounded)
        {
            //if (showJumpDebug)
            //{
            //    Debug.LogWarning("[Jump Debug] TryJump ����: IsGrounded = False");
            //}

            return;
        }

        VerticalVelocity = jumpPower;
        IsJumping = true;
        hasLeftGround = false;
        nextDebugTime = 0f;

        //if (showJumpDebug)
        //{
        //    Debug.Log(
        //        $"[Jump Debug] ���� ���� | " +
        //        $"IsJumping: {IsJumping}, " +
        //        $"HasLeftGround: {hasLeftGround}, " +
        //        $"VelocityY: {VerticalVelocity:F2}"
        //    );
        //}
    }

    public void UpdateVertical(bool isGrounded, float deltaTime)
    {
        // ���� ���� ��Ż ���� Ȯ��
        if (IsJumping && !isGrounded && !hasLeftGround)
        {
            hasLeftGround = true;

            //if (showJumpDebug)
            //{
            //    Debug.Log(
            //        "[Jump Debug] ���� ��Ż Ȯ�� | " +
            //        "HasLeftGround: True"
            //    );
            //}
        }

        // ���� ���� �ӵ� ó��
        if (!IsJumping && isGrounded)
        {
            if (VerticalVelocity < 0f)
            {
                VerticalVelocity = groundStickVelocity;
            }

            return;
        }

        // ���� �߷� ����
        ApplyGravity(deltaTime);
        LimitFallSpeed();

        // �ϰ� �� ���� ���� Ȯ��
        if (showJumpDebug &&
            IsJumping &&
            VerticalVelocity <= 0f &&
            Time.time >= nextDebugTime)
        {
            nextDebugTime = Time.time + 0.25f;

            //Debug.Log(
            //    $"[Jump Debug] �ϰ� ���� | " +
            //    $"CC Grounded: {isGrounded}, " +
            //    $"HasLeftGround: {hasLeftGround}, " +
            //    $"IsJumping: {IsJumping}, " +
            //    $"VelocityY: {VerticalVelocity:F2}"
            //);
        }

        // ���� ���� ���� ���� ����
        if (IsJumping &&
            hasLeftGround &&
            isGrounded &&
            VerticalVelocity <= 0f)
        {
            //if (showJumpDebug)
            //{
            //    Debug.Log(
            //        "[Jump Debug] ���� ���� ���� ���� �� EndJump ȣ��"
            //    );
            //}

            EndJump();
        }
    }

    private void ApplyGravity(float deltaTime)
    {
        VerticalVelocity +=
            Physics.gravity.y * gravityScale * deltaTime;
    }

    private void LimitFallSpeed()
    {
        if (VerticalVelocity < -maxFallSpeed)
        {
            VerticalVelocity = -maxFallSpeed;
        }
    }

    private void EndJump()
    {
        IsJumping = false;
        hasLeftGround = false;
        VerticalVelocity = groundStickVelocity;

        //if (showJumpDebug)
        //{
        //    Debug.Log(
        //        $"[Jump Debug] ���� ���� �Ϸ� | " +
        //        $"IsJumping: {IsJumping}, " +
        //        $"HasLeftGround: {hasLeftGround}, " +
        //        $"VelocityY: {VerticalVelocity:F2}"
        //    );
        //}
    }
}
